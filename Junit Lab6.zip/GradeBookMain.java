
public class GradeBookMain {

	public static void main(String[] args) {
		
		GradeBook gradeBook= new GradeBook(14);
		gradeBook.toString();
		// TODO Auto-generated method stub

	}

}
